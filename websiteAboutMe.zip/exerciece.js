
/*
//javascript types
//"локална променлива" 
let number = 2;
number++;
//"глобална променлива" 
var number3 = 3;

const variable1 = 10;
const variable2 = "something";
const variable3 = false;

//typeof variable1; ---> "number"
//variable1 + variable2 ----> "10something"

const number1 = '10';
const number2 = 20;

//sum --> Number(number1) + number2 ---> 30


const firstArray= [10, 'a', { prop: 'object'}, [1,2]];
console.log(firstArray[0]); // --> 10
console.log(firstArray[3][0]); //--> 1

//object
const objectVar = { prop1: 20, prop: 40};
//достъпване на обект
objectVar.prop1 //or objectVar['prop1'];

//оператори --> +, -, *, /, %, ** (повдигане на степен), ++, --
//оператори --> ==, ===, !=, !==, <, >, <=, >=
const result = 20 > 18; // --> true
const result1 = 20 === 20; //---> true
//разлика между == и ===
const stringValue = '20';
const numValue  = 20;
stringValue == numValue //-->true, не се интересува от типа на данните
stringValue === numValue //-->false, интересува се от типа на данните

//Lodash library for comparing Arrays and Objects
//logical operators &&, ||, !
!(20===20) //---> false
//function
const result2 = (() => {
    return 20;
})();


const func1 = function () {
    return 20;
}

function func2() {
    return 20;
}

console.log(result2, func1(), func2());
//loops
const blogPosts = [
    {
        title: 'What is JavaScript?',
        author: 'Maria Papazova',
        publishDate: 'Dec 20, 2020',
        content: '1some post content'
    },
    {
        title: 'What is JS?',
        author: 'Maria',
        publishDate: 'Dec 21, 2020',
        content: '2some post content'
    },
    {
        title: 'What is CSS?',
        author: 'Papazova',
        publishDate: 'Dec 22, 2020',
        content: '3some post content'
    }
];

for (let i = 0; i < blogPosts.length; i++) {
    const postTitle = blogPosts[i].title;
    const postAuthor = blogPosts[i].author;
    const postDate = blogPosts[i].publishDate;
    const postContent = blogPosts[i].content;

    console.log(postTitle);
    console.log(postAuthor);
    console.log(postDate);
    console.log(postContent);
};

const arr = ['sfgf', 'dsrg', 'rghsss', 20, 30];
for(let i = 0; i < arr.length; i++) {
    //if (typeof arr[i] === 'string') {
        console.log(arr[i]);
    //}
}

//immediately invoked func

(function anotherFunc() {
    console.log('hello');
})();


//func with parameters
function myFunc(param1, param2){
    console.log(param1);
    console.log(param2);
}

myFunc(20, 'func with param');

//buildin functions //https://www.tutorialspoint.com/javascript/index.htm

const myString = 'maria';
const newName = myString.replace('i', 'y');
//from string to array
let str = 'hello world';
const result3 = str.toUpperCase().split(" ");
console.log(result3);


function getAverage(marks){
    return Math.floor(marks.reduce((sum, x) => sum + x) / marks.length);
  }
*/
function myCallBack(someNumber) {
    return someNumber * 2;
}//equal to ----> (num) => num * 2;

function mainFunction(randomNumber, shouldCall, callback) {

    let result = randomNumber;

    if (shouldCall) {
        result = callback(randomNumber);
    }
    return result;
}

const regex = new RegExp('g');

const string1 = 'my favorite food is steak';
const string2 = 'my favorite thing to do is code';

regex.test(string1); //---> false  
regex.test(string2); //---> true

const regex2 = new RegExp('favorite');

regex2.test(string1); //---> true
regex2.test(string2); //---> true

/A-Za-z0-9/.test(string1); //---> true 

/^f/.test(string1); //---> false , проверява дали стрингът започва с f

/code|steak/.test(string1); //---> true 

/[a-z ]+/.exec(string1) //--> ["my favorite food is steak"]

const str = 'hello world, 2021 @ more of a string';

/^[a-z ]+,[0-9 ]+@[a-z ]+$/.exec(str); 
//равно на 
/.+/.exec(str);

//array methods 
//push() -> добавя елемент в края на масив/ pop() -> вади последния елемент от масив 
//shift() -> добавя елемент в нач на масив/ unshift() -> вади първия елемент от масив 
//slice() -> вади копие на масив от елементи от даден индекс до друг 
//splice() -> премахва/замества елемент в масив
//findIndex() --> връща индекса на който се среща търсения елемент 
//indexOf() --> 
//map()
//forEach()
//includes()
//filter()
//reduce()











//------------------------------------------------------------------
/*
const htmlBody = document.querySelector('body');

const randomClickFunction = function () {
    const color = ["#002942", "#0Ca7DB", "red", "blue", "purple"];

    const randomIndex = Math.floor(Math.random() * color.length);

    const randomColor = color[randomIndex];

    htmlBody.style.backgroundColor = randomColor;

    console.log('The user clicked and set the color to ' + randomColor)
}
//starting the function
randomClickFunction()
//onclick changing background colors
htmlBody.onclick = randomClickFunction;*/